# Interventional CGM dataset: paired factual / counterfactual episodes

Simulator-generated data accompanying an anonymous submission. Every episode is
simulated twice or more from an identical state: once as it actually unfolded
(the factual arm) and once per candidate insulin action (the counterfactual
arms). Because the arms share seed, patient, meal schedule and history, the
difference between them is the causal effect of the action, which observational
CGM data cannot provide.

## Contents

    processed/            model-ready CSVs (the split used for all reported results)
      train.csv           factual prefixes, 70 patients / 280 sequences
      val.csv             factual prefixes, 10 patients / 38 sequences
      test_prefix.csv     history for the 20 held-out patients, 80 episodes
      test_suffix.csv     factual + counterfactual futures for those episodes
      test_scenarios.csv  one row per (episode, action): name, family, validity
      metadata.json       split sizes, channels, action menus, horizon

    raw_episodes/         per-episode simulator output, for provenance
      basal_and_original_bolus_menu/patient_XXX/episode_YY/
      add_average_bolus_menu/patient_XXX/episode_YY/
        manifest.csv        one row per scenario: seed, perturbation window,
                            target bolus, validity
        prefix_factual.csv  the shared history
        suffix_<name>.csv   one file per action

## Format

Channels are `cgm` (mg/dL), `basal` (U per 5-min step), `bolus` (U), `meal` (g).
Sampling is 5 minutes. Prefixes are 288 steps (24 h); counterfactual suffixes are
49 rows, a t=0 boundary row plus 48 steps (4 h).

Rows are keyed by `pat_id`, `seq_id` and `episode_id`. Note that `seq_id` is a
global counter assigned at preprocessing time: join on `(pat_id, episode_id)`
when relating these files to any other build of the data.

`scenario_type` is `factual` or `counterfactual`; `perturb_family` is `basal`,
`bolus` or `none`.

## Action menus

Basal, applied as a multiplier on the delivered rate over the perturbation
window: 0, 0.5, 1.5, 2, 2.5, 3, 3.5, 4x. The factual rate (1x) is the factual
arm and is not repeated in the menu.

Bolus, `bolus_add_avg_<s>x`, adding s times the patient's mean bolus at the
perturbation start: 0.00 to 3.00 in steps of 0.25. This menu is defined for
every episode. The tree also carries an older bolus set (`bolus_0x`, `0.5x`,
`2x`, `advance_30`, `delay_30`, `add_avg_now`) that rescales or moves a
*pre-existing* bolus and is therefore only valid where one exists; those
scenarios cover 41 of the 80 episodes and are kept for completeness.

## Caveats worth knowing before using this

The action menus are censored. The cost-minimising basal rate is the 4x ceiling
in 47.5% of episodes and the cost-minimising bolus dose is the 3x ceiling in
47.5%, so the oracle would prefer actions that were not simulated. Any
action-selection metric computed here is measured against a truncated action
space, and constant-action baselines are correspondingly strong.

Episode placement depends on the horizon: the selection rule enforces
non-overlap with the previous perturbation window, so 15 of 80 episodes sit at a
different window than in a 2-hour build of the same pipeline. Use `test_prefix`
from this release rather than from another build.

Meals are held fixed across the arms of an episode and are not an input to any
model evaluated on the counterfactual arm.

## Integrity

    sha256sum -c SHA256SUMS
