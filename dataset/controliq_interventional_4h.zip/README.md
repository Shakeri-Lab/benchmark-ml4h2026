# Four-Hour Control-IQ Simulator Intervention Dataset

Alireza Namazi and Heman Shakeri prepared this dataset for *From Prediction to
Practice: A Task-Aware Evaluation Framework for Blood Glucose Forecasting*
(ML4H 2026, PMLR 346). It contains glucose and insulin trajectories generated
with adult virtual subjects from the UVA/Padova simulator under a simulator
implementation of Control-IQ. The clinical cohorts used for the hypoglycemia
warning evaluation are distributed separately by their data providers.

Each intervention episode pairs a factual trajectory with alternative insulin
plans that share the same starting state, history, and future meals. The paper
evaluates sustained basal-rate multipliers and added boluses over four hours.
Signals are sampled every five minutes. The channels are `cgm` (mg/dL),
`basal` (U per five-minute interval), `bolus` (U), and `meal` (g).

## Files

Inside `controliq_interventional_4h/`:

| Path | Contents |
| --- | --- |
| `processed/train.csv` | Factual histories from 70 virtual subjects (280 sequences) |
| `processed/val.csv` | Factual histories from 10 virtual subjects (38 sequences) |
| `processed/test_prefix.csv` | Shared histories for 80 episodes from 20 held-out virtual subjects |
| `processed/test_suffix.csv` | Factual and counterfactual trajectories, with the boundary sample and 48 subsequent steps per scenario |
| `processed/test_scenarios.csv` | Scenario names, intervention families, and validity flags |
| `raw_episodes/` | Per-episode simulator output and scenario manifests |
| `SHA256SUMS` | Checksums for the original OSF files |

Processed histories can extend beyond the 24-hour model input window. The
archive also preserves earlier bolus perturbations. For the published bolus
analysis, use the `bolus_add_avg_*` scenarios and follow the [reproduction
guide](https://github.com/Shakeri-Lab/benchmark-ml4h2026/blob/ml4h2026-v1.0.0/ml4h2026/REPRODUCE.md).
The processed test CSVs contain 2,109 scenarios in total. The test totals in
the original `processed/metadata.json` refer to an earlier build.

The original files came from [OSF](https://osf.io/5rzsg/). The five processed
CSVs match the benchmark copy used for the paper. To verify the original
archive members after extraction, run:

```bash
cd controliq_interventional_4h
shasum -a 256 -c SHA256SUMS
```

## Citation

Please cite the paper when using the dataset:

```bibtex
@inproceedings{namazi2026prediction,
  title = {From Prediction to Practice: A Task-Aware Evaluation Framework for Blood Glucose Forecasting},
  author = {Namazi, Alireza and Shakeri, Heman},
  booktitle = {Proceedings of Machine Learning for Health},
  series = {Proceedings of Machine Learning Research},
  volume = {346},
  year = {2026},
  url = {https://github.com/Shakeri-Lab/benchmark-ml4h2026/tree/ml4h2026-v1.0.0}
}
```
